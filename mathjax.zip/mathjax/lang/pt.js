/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'mathjax', 'pt', {
	title: 'Matemática em TeX',
	button: 'Matemática',
	dialogInput: 'Escreva aqui o seu TeX',
	docUrl: 'http://en.wikibooks.org/wiki/LaTeX/Mathematics',
	docLabel: 'Documentação TeX',
	loading: 'a carregar ...',
	pathName: 'matemática'
} );
